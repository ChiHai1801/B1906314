<!DOCTYPE HTML>
<html>  
<body>

<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Nhập mật khẩu <input type="password" name="pwd"><br>
ngày sinh <input type="date" name="nsinh"><br>
<input type="submit">
</form>

</body>
</html>
